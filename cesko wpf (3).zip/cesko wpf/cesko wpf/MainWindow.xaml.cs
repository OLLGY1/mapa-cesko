﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace cesko_wpf
{ 

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
    {
    Random rand = new Random();
    string NahodnyMesto;
    int NahodnyCislo;
        int Body = 0;
    List<MapPoint> points = new List<MapPoint>()
    {
        new MapPoint( "Praha", 0.38,  0.38),
        new MapPoint( "Brno", 0.69,  0.72),
        new MapPoint( "Ostrava", 0.91,  0.48),
    };

    public MainWindow()
    {
        InitializeComponent();
        Loaded += MainWindow_Loaded;
            Console.WriteLine(NahodnyMesto);
            Kolo();
    }

    public void Kolo()
        {
            NahodnyCislo = rand.Next(points.Count);
            NahodnyMesto = points[NahodnyCislo].Name;
            MessageBox.Show(NahodnyMesto);
        }
    void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        DrawPoints();
    }

    private void MapImage_SizeChanged(object sender, SizeChangedEventArgs e)
    {
        DrawPoints();

        }

    void DrawPoints()
    {
        OverlayCanvas.Children.Clear();

        foreach (var point in points)
        {
            double x = MapImage.ActualWidth * point.XPercent;
            double y = MapImage.ActualHeight * point.YPercent;

            Button btn = new Button()
            {
                Content = point.Name,
                Tag = point
            };

            btn.Click += Btn_Click;

            Canvas.SetLeft(btn, x);
            Canvas.SetTop(btn, y);

            OverlayCanvas.Children.Add(btn);
        }
    }

    private void Btn_Click(object sender, RoutedEventArgs e)
    {
        Button btn = sender as Button;
        MapPoint point = btn.Tag as MapPoint;

            if (NahodnyMesto == point.Name)
            {
                MessageBox.Show("Yuhhhh");
                points.RemoveAt(NahodnyCislo);
                Body += 1;

                if (points.Count > 0)
                {
                    Kolo();
                }
                else
                {
                    MessageBox.Show($"Konec hry! tvůj počet bodů je {Body}");
                    Close();
                }
            }
            else
            {
                MessageBox.Show($"Nuhhhhh! Todle je {point.Name}. Tvůj počet bodů byl {Body}");
                Close();
            }
        }
    //private void MapImage_MouseDown(object sender, MouseButtonEventArgs e)
    //{
     //   var pos = e.GetPosition(MapImage);
     //
       // double xPercent = pos.X / MapImage.ActualWidth;
        //double yPercent = pos.Y / MapImage.ActualHeight;

        //MessageBox.Show($"{xPercent:F4} , {yPercent:F4}");
    //}
}
}