﻿using System;
using System.Collections.Generic;
using System.Text;

namespace cesko_wpf
{
    public class MapPoint
    {
        public string Name { get; set; }
        public double XPercent { get; set; }
        public double YPercent { get; set; }
        public MapPoint(string name, double xPercent, double yPercent) {
            Name = name;
            XPercent = xPercent;
            YPercent = yPercent;
        
        }
    }
}
